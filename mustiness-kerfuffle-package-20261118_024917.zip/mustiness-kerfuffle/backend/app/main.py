from fastapi import FastAPI

from app.api.v1.access_codes import router as access_codes_router
from app.api.v1.auth import router as auth_router
from app.api.v1.events import router as events_router
from app.api.v1.health import router as health_router
from app.api.v1.leaderboard import router as leaderboard_router
from app.api.v1.me import router as me_router
from app.api.v1.organizer_admin import router as organizer_admin_router
from app.api.v1.organizer_admin import public_router as public_account_router
from app.api.v1.participants import router as participants_router
from app.api.v1.route_sheets import router as route_sheets_router
from app.api.v1.scores import router as scores_router
from app.api.v1.stations import router as stations_router
from app.core.config import get_settings

settings = get_settings()

app = FastAPI(
    title=settings.app_name,
    version="0.1.0",
    description="Backend сервиса мероприятий Kerfuffle.",
    docs_url=None if settings.environment.lower() == "production" else "/docs",
    redoc_url=None if settings.environment.lower() == "production" else "/redoc",
    openapi_url=None if settings.environment.lower() == "production" else "/openapi.json",
)

app.include_router(health_router, prefix=settings.api_v1_prefix)
app.include_router(access_codes_router, prefix=settings.api_v1_prefix)
app.include_router(auth_router, prefix=settings.api_v1_prefix)
app.include_router(me_router, prefix=settings.api_v1_prefix)
app.include_router(organizer_admin_router, prefix=settings.api_v1_prefix)
app.include_router(public_account_router, prefix=settings.api_v1_prefix)
app.include_router(events_router, prefix=settings.api_v1_prefix)
app.include_router(stations_router, prefix=settings.api_v1_prefix)
app.include_router(participants_router, prefix=settings.api_v1_prefix)
app.include_router(route_sheets_router, prefix=settings.api_v1_prefix)
app.include_router(scores_router, prefix=settings.api_v1_prefix)
app.include_router(leaderboard_router, prefix=settings.api_v1_prefix)


@app.middleware("http")
async def disable_api_response_caching(request, call_next):
    response = await call_next(request)
    if request.url.path.startswith(settings.api_v1_prefix):
        response.headers["Cache-Control"] = "no-store"
        response.headers["Pragma"] = "no-cache"
        response.headers["X-Content-Type-Options"] = "nosniff"
    return response


@app.get("/", tags=["Root"])
def root():
    return {
        "name": settings.app_name,
        "version": "0.1.0",
        "docs": None if settings.environment.lower() == "production" else "/docs",
    }
